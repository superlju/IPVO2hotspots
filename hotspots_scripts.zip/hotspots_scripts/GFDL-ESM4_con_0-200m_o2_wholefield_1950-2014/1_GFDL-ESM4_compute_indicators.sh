#!/bin/bash
#module load cdo  # uncomment if you have to load the module

# FIRST: Copy the data from their folder to here


# ----------------------------------------------
# Get 0-200m Oxygen data, whole period available: 
# ----------------------------------------------

cp ../data_per_hotspot/GFDL-ESM4_vertinv_o2_0-200m_pycomputed_daytoset.nc . # copy file from there to here

cdo setday,15 GFDL-ESM4_vertinv_o2_0-200m_pycomputed_daytoset.nc GFDL-ESM4_vertinv_o2_0-200m_pycomputed.nc
# save space
rm ./GFDL-ESM4_vertinv_o2_0-200m_pycomputed_daytoset.nc  # remove useless file to make space here

# Set Missing Values to 1e+20 instead of NaN and remove useless tmp data
#cdo setmissval,1e+20 GFDL-ESM4_vertinv_o2_0-200m_pycomputed_missnans.nc GFDL-ESM4_vertinv_o2_0-200m_pycomputed.nc
#rm *missnans.nc

# ---------------------------------------------------
# Get 0-200m IPVstar data, whole period available: 
# ---------------------------------------------------
cp ../data_per_hotspot/GFDL-ESM4_vertinv_IPVstar_0-200m_pycomputed_daytoset.nc . # copy file from there to here

cdo setday,15 GFDL-ESM4_vertinv_IPVstar_0-200m_pycomputed_daytoset.nc GFDL-ESM4_vertinv_IPVstar_0-200m_pycomputed.nc

rm ./GFDL-ESM4_vertinv_IPVstar_0-200m_pycomputed_daytoset.nc # remove useless file to make space here

# Set Missing Values to 1e+20 instead of NaN and remove useless tmp data
#cdo setmissval,1e+20 GFDL-ESM4_vertinv_IPVstar_0-200m_pycomputed_missnans.nc GFDL-ESM4_vertinv_IPVstar_0-200m_pycomputed.nc
#rm *missnans.nc

# ==============================================
# Select the two periods: "before" and "after"
# ==============================================
# ---------------------------------------------------------------------------------------------------------------

# o2: 
cdo selyear,1950/1981 GFDL-ESM4_vertinv_o2_0-200m_pycomputed.nc GFDL-ESM4_vertinv_o2_0-200m_before.nc
cdo selyear,1983/2014 GFDL-ESM4_vertinv_o2_0-200m_pycomputed.nc GFDL-ESM4_vertinv_o2_0-200m_after.nc

# ipvstar:
cdo selyear,1950/1981 GFDL-ESM4_vertinv_IPVstar_0-200m_pycomputed.nc GFDL-ESM4_vertinv_IPVstar_0-200m_before.nc
cdo selyear,1983/2014 GFDL-ESM4_vertinv_IPVstar_0-200m_pycomputed.nc GFDL-ESM4_vertinv_IPVstar_0-200m_after.nc

# ----------------------------------------------------------------------------------------------------------------



# ------------------------------------------------
# Indicator: (1) for 0-200m o2 , (4) for IPV* 
# ------------------------------------------------
 
# Compute seasonal mean over the entire periods separately, i.e. multi-year seasonal mean

 # o2:
 cdo yseasmean GFDL-ESM4_vertinv_o2_0-200m_before.nc outputyseasm_GFDL-ESM4_vertinv_o2_0-200m_before.nc
 cdo yseasmean GFDL-ESM4_vertinv_o2_0-200m_after.nc outputyseasm_GFDL-ESM4_vertinv_o2_0-200m_after.nc

 # ipvstar:
 cdo yseasmean GFDL-ESM4_vertinv_IPVstar_0-200m_before.nc outputyseasm_GFDL-ESM4_vertinv_IPVstar_0-200m_before.nc
 cdo yseasmean GFDL-ESM4_vertinv_IPVstar_0-200m_after.nc outputyseasm_GFDL-ESM4_vertinv_IPVstar_0-200m_after.nc


# for each season: yseasmean_after - yseasmean_before
  
 # o2:
 cdo sub outputyseasm_GFDL-ESM4_vertinv_o2_0-200m_after.nc outputyseasm_GFDL-ESM4_vertinv_o2_0-200m_before.nc ind1_0-200m_o2.nc        # This is indicator (1) for o2. Seasons are included in the file as 4 different timesteps.


 # ipvstar:
 cdo sub outputyseasm_GFDL-ESM4_vertinv_IPVstar_0-200m_after.nc outputyseasm_GFDL-ESM4_vertinv_IPVstar_0-200m_before.nc ind4_0-200m_IPVstar.nc        # This is indicator (4) for ipv star. Seasons are included in the file as 4 different timesteps.



# --------------------------------------------------
# Compute Indicators: (2) for o2, (5) for IPVstar
# --------------------------------------------------

# detrend the o2 separately in each period:

  cdo detrend GFDL-ESM4_vertinv_o2_0-200m_before.nc detr_GFDL-ESM4_vertinv_o2_0-200m_before.nc
  cdo detrend GFDL-ESM4_vertinv_o2_0-200m_after.nc detr_GFDL-ESM4_vertinv_o2_0-200m_after.nc

# detrend the ipvstar separately in each period:

  cdo detrend GFDL-ESM4_vertinv_IPVstar_0-200m_before.nc detr_GFDL-ESM4_vertinv_IPVstar_0-200m_before.nc
  cdo detrend GFDL-ESM4_vertinv_IPVstar_0-200m_after.nc detr_GFDL-ESM4_vertinv_IPVstar_0-200m_after.nc


# compute interannual standard deviation for each season separately 
# For example I compute the year-to-year standard deviation for each season separately, as a measure for variability.

  # o2: 
  cdo yseasstd detr_GFDL-ESM4_vertinv_o2_0-200m_before.nc yseasstd_detr_GFDL-ESM4_vertinv_o2_0-200m_before.nc
  cdo yseasstd detr_GFDL-ESM4_vertinv_o2_0-200m_after.nc yseasstd_detr_GFDL-ESM4_vertinv_o2_0-200m_after.nc
  
  # ipvstar: 
  cdo yseasstd detr_GFDL-ESM4_vertinv_IPVstar_0-200m_before.nc yseasstd_detr_GFDL-ESM4_vertinv_IPVstar_0-200m_before.nc
  cdo yseasstd detr_GFDL-ESM4_vertinv_IPVstar_0-200m_after.nc yseasstd_detr_GFDL-ESM4_vertinv_IPVstar_0-200m_after.nc



# compute the % change of this, for each season separately 
# 100*[(after - before)/before]

  # o2:
  cdo sub yseasstd_detr_GFDL-ESM4_vertinv_o2_0-200m_after.nc yseasstd_detr_GFDL-ESM4_vertinv_o2_0-200m_before.nc  dopo_meno_prima_o2.nc        # dopo - prima 
  cdo div dopo_meno_prima_o2.nc yseasstd_detr_GFDL-ESM4_vertinv_o2_0-200m_before.nc dopo_meno_prima_fratto_prima_o2.nc 
  cdo mulc,100 dopo_meno_prima_fratto_prima_o2.nc ind2_0-200m_o2.nc      # This is indicator (2) for 0-200m o2

  # clean up space: 
  rm *dopo_meno_prima*


  # ipvstar:
  cdo sub yseasstd_detr_GFDL-ESM4_vertinv_IPVstar_0-200m_after.nc yseasstd_detr_GFDL-ESM4_vertinv_IPVstar_0-200m_before.nc  dopo_meno_prima_IPVstar.nc        # dopo - prima 
  cdo div dopo_meno_prima_IPVstar.nc yseasstd_detr_GFDL-ESM4_vertinv_IPVstar_0-200m_before.nc dopo_meno_prima_fratto_prima_IPVstar.nc 
  cdo mulc,100 dopo_meno_prima_fratto_prima_IPVstar.nc ind5_0-200m_IPVstar.nc      # This is indicator (5) for 0-200m IPVstar

  # clean up space: 
  rm *dopo_meno_prima*



# Compute Indicators: (3) for o2(min) and (6) for IPVstar(max): min of o2 (deoxygenation) and max of IPV star (max in stratification)

# compute the MIN reached by O2, the MAXIMUM reached by IPVstar (separately), 
# in each season separately, in the "before" period: 


# These are the thresholds: 
 
 # o2 - look for MIN (interest in de-oxygenation)
 cdo yseasmin GFDL-ESM4_vertinv_o2_0-200m_before.nc yseasmin_GFDL-ESM4_vertinv_o2_0-200m_before.nc   # multi-year seasonal min. For each season separately. (i.e. 4 timesteps) 
 
 # ipvstar - look for MAX
 cdo yseasmax GFDL-ESM4_vertinv_IPVstar_0-200m_before.nc yseasmax_GFDL-ESM4_vertinv_IPVstar_0-200m_before.nc   # multi-year seasonal max. For each season separately


# Number of times each season in the "after" period that (separately) exceeds the value yseasmin_o2_before.nc of the corresponding season. 

 # First: compare the field with the threshold, in each season in each gridpoint and 
 # give as output a mask where 1 means o2 < threshold (and > threshold for ipvstar), 0 othewise. 
 # And this must be done for each season separately. 
 
 # So I first split seasons: 
 # these commands will generate files like these: "splitseas_blabla_after_DJF.nc", "splitseas_blabla_after_MAM.nc", etc.. 
      
   # o2:
   cdo splitseas GFDL-ESM4_vertinv_o2_0-200m_after.nc splitseas_GFDL-ESM4_vertinv_o2_0-200m_after_

   # ipvstar: 
   cdo splitseas GFDL-ESM4_vertinv_IPVstar_0-200m_after.nc splitseas_GFDL-ESM4_vertinv_IPVstar_0-200m_after_

  

 # And I also split the threshold in four seasons: 
   
   # o2: split thr (min) in seasons
   cdo splitseas yseasmin_GFDL-ESM4_vertinv_o2_0-200m_before.nc yseasmin_GFDL-ESM4_vertinv_o2_0-200m_before_
   
   # ipvstar: split thr (max) in seasons
   cdo splitseas yseasmax_GFDL-ESM4_vertinv_IPVstar_0-200m_before.nc yseasmax_GFDL-ESM4_vertinv_IPVstar_0-200m_before_
  


 # Then, for each season, I compare with the threshold: 

   # o2 (look for undershots, so: 1 if first input < second input) - metto 1 se after è più basso di before

   cdo lt splitseas_GFDL-ESM4_vertinv_o2_0-200m_after_DJF.nc yseasmin_GFDL-ESM4_vertinv_o2_0-200m_before_DJF.nc  mask_o2_DJF.nc
   cdo lt splitseas_GFDL-ESM4_vertinv_o2_0-200m_after_MAM.nc yseasmin_GFDL-ESM4_vertinv_o2_0-200m_before_MAM.nc  mask_o2_MAM.nc 
   cdo lt splitseas_GFDL-ESM4_vertinv_o2_0-200m_after_JJA.nc yseasmin_GFDL-ESM4_vertinv_o2_0-200m_before_JJA.nc  mask_o2_JJA.nc
   cdo lt splitseas_GFDL-ESM4_vertinv_o2_0-200m_after_SON.nc yseasmin_GFDL-ESM4_vertinv_o2_0-200m_before_SON.nc  mask_o2_SON.nc



   # ipvstar (look for overshots, so: 1 if first input > second input), i.e  I put a 1 if "after" is higher than "before" 
   cdo gt splitseas_GFDL-ESM4_vertinv_IPVstar_0-200m_after_DJF.nc yseasmax_GFDL-ESM4_vertinv_IPVstar_0-200m_before_DJF.nc  mask_ipv_DJF.nc
   cdo gt splitseas_GFDL-ESM4_vertinv_IPVstar_0-200m_after_MAM.nc yseasmax_GFDL-ESM4_vertinv_IPVstar_0-200m_before_MAM.nc  mask_ipv_MAM.nc 
   cdo gt splitseas_GFDL-ESM4_vertinv_IPVstar_0-200m_after_JJA.nc yseasmax_GFDL-ESM4_vertinv_IPVstar_0-200m_before_JJA.nc  mask_ipv_JJA.nc
   cdo gt splitseas_GFDL-ESM4_vertinv_IPVstar_0-200m_after_SON.nc yseasmax_GFDL-ESM4_vertinv_IPVstar_0-200m_before_SON.nc  mask_ipv_SON.nc


 # Then I count how many times it happens, for each seasons separately
 # Aka I sum all the 1 that I obtained. It's sum over all time steps.
 
   # o2
   cdo timsum mask_o2_DJF.nc occurrences_o2_DJF_wrongdate.nc 
   cdo timsum mask_o2_MAM.nc occurrences_o2_MAM_wrongdate.nc 
   cdo timsum mask_o2_JJA.nc occurrences_o2_JJA_wrongdate.nc 
   cdo timsum mask_o2_SON.nc occurrences_o2_SON_wrongdate.nc 
   
   # ipvstar 
   cdo timsum mask_ipv_DJF.nc occurrences_ipv_DJF_wrongdate.nc
   cdo timsum mask_ipv_MAM.nc occurrences_ipv_MAM_wrongdate.nc
   cdo timsum mask_ipv_JJA.nc occurrences_ipv_JJA_wrongdate.nc
   cdo timsum mask_ipv_SON.nc occurrences_ipv_SON_wrongdate.nc


# ---------------------------------------------------------
# Adjust the date in each season, because it shifted due to the cdo 
# calculation but it shouldn't be, and you know that it's actually in that season.
# ---------------------------------------------------------
# la metto sempre all'ultimo mese della season in questione.

# o2:
cdo setdate,2014-02-15 occurrences_o2_DJF_wrongdate.nc occurrences_o2_DJF.nc
cdo setdate,2014-05-15 occurrences_o2_MAM_wrongdate.nc occurrences_o2_MAM.nc
cdo setdate,2014-08-15 occurrences_o2_JJA_wrongdate.nc occurrences_o2_JJA.nc
cdo setdate,2014-11-15 occurrences_o2_SON_wrongdate.nc occurrences_o2_SON.nc

# ipvstar:
cdo setdate,2014-02-15 occurrences_ipv_DJF_wrongdate.nc occurrences_ipv_DJF.nc
cdo setdate,2014-05-15 occurrences_ipv_MAM_wrongdate.nc occurrences_ipv_MAM.nc
cdo setdate,2014-08-15 occurrences_ipv_JJA_wrongdate.nc occurrences_ipv_JJA.nc
cdo setdate,2014-11-15 occurrences_ipv_SON_wrongdate.nc occurrences_ipv_SON.nc


# And finally I want the % of that, for each season separately : 
# perc_occurr = 100(number_occurrences/total_timesteps) 
#  
# 96 month tot (32 full years, seasonally divided, that is 32*3 =96)

# sono 32 full years perchè ho before = 1950-1981 = 32 full years, after = 1983-2014 = 32 full years. 
  # o2:
  cdo divc,96 occurrences_o2_DJF.nc occurrences_on_Ntot_o2_DJF.nc
  cdo divc,96 occurrences_o2_MAM.nc occurrences_on_Ntot_o2_MAM.nc
  cdo divc,96 occurrences_o2_JJA.nc occurrences_on_Ntot_o2_JJA.nc
  cdo divc,96 occurrences_o2_SON.nc occurrences_on_Ntot_o2_SON.nc
  
  # ipvstar:
  cdo divc,96 occurrences_ipv_DJF.nc occurrences_on_Ntot_ipv_DJF.nc
  cdo divc,96 occurrences_ipv_MAM.nc occurrences_on_Ntot_ipv_MAM.nc
  cdo divc,96 occurrences_ipv_JJA.nc occurrences_on_Ntot_ipv_JJA.nc
  cdo divc,96 occurrences_ipv_SON.nc occurrences_on_Ntot_ipv_SON.nc
 
 

# Multiply by 100 to get the percentage 
  # o2
  cdo mulc,100 occurrences_on_Ntot_o2_DJF.nc ind3_0-200m_o2_DJF.nc # This is indicator (3)-WINTER for o2
  cdo mulc,100 occurrences_on_Ntot_o2_MAM.nc ind3_0-200m_o2_MAM.nc # This is indicator (3)-SPRING for o2
  cdo mulc,100 occurrences_on_Ntot_o2_JJA.nc ind3_0-200m_o2_JJA.nc # This is indicator (3)-SUMMER for o2
  cdo mulc,100 occurrences_on_Ntot_o2_SON.nc ind3_0-200m_o2_SON.nc # This is indicator (3)-AUTUMN for o2

  # ipv
  cdo mulc,100 occurrences_on_Ntot_ipv_DJF.nc ind6_ipv_DJF.nc # This is indicator (6)-WINTER for ipvstar
  cdo mulc,100 occurrences_on_Ntot_ipv_MAM.nc ind6_ipv_MAM.nc # This is indicator (6)-SPRING for ipvstar
  cdo mulc,100 occurrences_on_Ntot_ipv_JJA.nc ind6_ipv_JJA.nc # This is indicator (6)-SUMMER for ipvstar
  cdo mulc,100 occurrences_on_Ntot_ipv_SON.nc ind6_ipv_SON.nc # This is indicator (6)-AUTUMN for ipvstar
  


# If we want all the seasons in a single file, then we merge:  
  # o2:
  cdo mergetime ind3_0-200m_o2_DJF.nc ind3_0-200m_o2_MAM.nc ind3_0-200m_o2_JJA.nc ind3_0-200m_o2_SON.nc ind3_0-200m_o2.nc # Finally, this is the indicator (3) for o2 with all the seasons as different timesteps inthe same file.nc 
 
  # ipvstar:
  cdo mergetime ind6_ipv_DJF.nc ind6_ipv_MAM.nc ind6_ipv_JJA.nc ind6_ipv_SON.nc ind6_0-200m_IPVstar.nc 


 

# Potentially usefull stuff: Aggiungo io anche la media sulle stagioni di ogni indicatore. Cioè invece di avere 4 mappe per ogni
# indicatore (una per season) faccio la media di esse e ne ho una. E anche la std-dev. 
# Metterò le seasonal maps nel suppl e la loro media e std nel main (facendo vedere che non cambia molto tra queste mappe)
cdo timmean  ind1_0-200m_o2.nc timmean_ind1.nc
cdo timmean  ind2_0-200m_o2.nc timmean_ind2.nc
cdo timmean  ind3_0-200m_o2.nc timmean_ind3.nc
cdo timmean  ind4_0-200m_IPVstar.nc timmean_ind4.nc
cdo timmean  ind5_0-200m_IPVstar.nc timmean_ind5.nc
cdo timmean  ind6_0-200m_IPVstar.nc timmean_ind6.nc

cdo timstd  ind1_0-200m_o2.nc timstd_ind1.nc
cdo timstd  ind2_0-200m_o2.nc timstd_ind2.nc
cdo timstd  ind3_0-200m_o2.nc timstd_ind3.nc
cdo timstd  ind4_0-200m_IPVstar.nc timstd_ind4.nc
cdo timstd  ind5_0-200m_IPVstar.nc timstd_ind5.nc
cdo timstd  ind6_0-200m_IPVstar.nc timstd_ind6.nc

# Now let's compute The hotspot index as in Turco et. al. 2015: 

#  SED = sqrt[sommatoria_sugli_indicatori di (sommatoria_sulle_seasons di((indicatore_i_stagione_j)^2./(p95(indicatore_i_stagionej))))]; 

#  1. Absolute value of each indicator 
  
   # o2
   cdo abs ind1_0-200m_o2.nc abs_ind1.nc
   cdo abs ind2_0-200m_o2.nc abs_ind2.nc
   cdo abs ind3_0-200m_o2.nc abs_ind3.nc
   
   # ipvstar
   cdo abs ind4_0-200m_IPVstar.nc abs_ind4.nc
   cdo abs ind5_0-200m_IPVstar.nc abs_ind5.nc
   cdo abs ind6_0-200m_IPVstar.nc abs_ind6.nc

  

#  2. the 95th percentile of each abs_ind, for each season separately. 

   # o2
   cdo fldpctl,95 abs_ind1.nc p95_absind1.nc 
   cdo fldpctl,95 abs_ind2.nc p95_absind2.nc 
   cdo fldpctl,95 abs_ind3.nc p95_absind3.nc 

   # ipvstar
   cdo fldpctl,95 abs_ind4.nc p95_absind4.nc
   cdo fldpctl,95 abs_ind5.nc p95_absind5.nc
   cdo fldpctl,95 abs_ind6.nc p95_absind6.nc

   # split seasons: 
   
   # o2
   cdo splitseas p95_absind1.nc p95_abs_ind1_  
   cdo splitseas p95_absind2.nc p95_abs_ind2_
   cdo splitseas p95_absind3.nc p95_abs_ind3_

   # ipvstar
   cdo splitseas p95_absind4.nc p95_abs_ind4_
   cdo splitseas p95_absind5.nc p95_abs_ind5_
   cdo splitseas p95_absind6.nc p95_abs_ind6_
   



# THIS IS NOT YET THE SED. Please type cdo infon for each of the p95_abs_ind1_ .. above
# in order to show the normalization constant. 

  mv *.nc tmp_files 
  

  # o2
  mv tmp_files/ind1_0-200m_o2.nc .
  mv tmp_files/ind2_0-200m_o2.nc .
  mv tmp_files/ind3_0-200m_o2.nc .
  mv tmp_files/p95_abs_ind1_* .
  mv tmp_files/p95_abs_ind2_* .
  mv tmp_files/p95_abs_ind3_* .
  
  mv tmp_files/timmean_ind* .
  mv tmp_files/timstd_ind* .
  
  # ipvstar
  mv tmp_files/ind4_0-200m_IPVstar.nc .
  mv tmp_files/ind5_0-200m_IPVstar.nc .
  mv tmp_files/ind6_0-200m_IPVstar.nc .
  mv tmp_files/p95_abs_ind4_* .
  mv tmp_files/p95_abs_ind5_* .
  mv tmp_files/p95_abs_ind6_* .




 cdo splitseas ind1_0-200m_o2.nc ind1_
 cdo splitseas ind2_0-200m_o2.nc ind2_
 cdo splitseas ind3_0-200m_o2.nc ind3_
 
 cdo splitseas ind4_0-200m_IPVstar.nc ind4_
 cdo splitseas ind5_0-200m_IPVstar.nc ind5_
 cdo splitseas ind6_0-200m_IPVstar.nc ind6_


# rm every tmp file to save space

rm ./tmp_files/*.nc 


