#!/bin/bash

# 1. get grid.dat file that contains grid structure: 

cdo griddes ind1_DJF.nc > grid.dat  # it's the same for all the ind so I just do this once. 

# ==============================================================================
# This part below is improved. It reads the percentiles automatically, i.e. 
# there is no need to run the 2_blabla.sh file anymore. (removed)
# ==============================================================================

# 2. Transform percentiles files from point values to grid values, otherwise we can't divide: 
# grid is teh grid of the data 

cdo enlarge,grid.dat p95_abs_ind1_DJF.nc gridded_p95_abs_ind1_DJF.nc    # gridded percentile. 
cdo enlarge,grid.dat p95_abs_ind2_DJF.nc gridded_p95_abs_ind2_DJF.nc 
cdo enlarge,grid.dat p95_abs_ind3_DJF.nc gridded_p95_abs_ind3_DJF.nc 
cdo enlarge,grid.dat p95_abs_ind4_DJF.nc gridded_p95_abs_ind4_DJF.nc 
cdo enlarge,grid.dat p95_abs_ind5_DJF.nc gridded_p95_abs_ind5_DJF.nc 
cdo enlarge,grid.dat p95_abs_ind6_DJF.nc gridded_p95_abs_ind6_DJF.nc 

cdo enlarge,grid.dat p95_abs_ind1_MAM.nc gridded_p95_abs_ind1_MAM.nc    # percentile grigliato, non più numero singolo. 
cdo enlarge,grid.dat p95_abs_ind2_MAM.nc gridded_p95_abs_ind2_MAM.nc 
cdo enlarge,grid.dat p95_abs_ind3_MAM.nc gridded_p95_abs_ind3_MAM.nc 
cdo enlarge,grid.dat p95_abs_ind4_MAM.nc gridded_p95_abs_ind4_MAM.nc 
cdo enlarge,grid.dat p95_abs_ind5_MAM.nc gridded_p95_abs_ind5_MAM.nc 
cdo enlarge,grid.dat p95_abs_ind6_MAM.nc gridded_p95_abs_ind6_MAM.nc

cdo enlarge,grid.dat p95_abs_ind1_JJA.nc gridded_p95_abs_ind1_JJA.nc    # percentile grigliato, non più numero singolo. 
cdo enlarge,grid.dat p95_abs_ind2_JJA.nc gridded_p95_abs_ind2_JJA.nc 
cdo enlarge,grid.dat p95_abs_ind3_JJA.nc gridded_p95_abs_ind3_JJA.nc 
cdo enlarge,grid.dat p95_abs_ind4_JJA.nc gridded_p95_abs_ind4_JJA.nc 
cdo enlarge,grid.dat p95_abs_ind5_JJA.nc gridded_p95_abs_ind5_JJA.nc 
cdo enlarge,grid.dat p95_abs_ind6_JJA.nc gridded_p95_abs_ind6_JJA.nc

cdo enlarge,grid.dat p95_abs_ind1_SON.nc gridded_p95_abs_ind1_SON.nc    # percentile grigliato, non più numero singolo. 
cdo enlarge,grid.dat p95_abs_ind2_SON.nc gridded_p95_abs_ind2_SON.nc 
cdo enlarge,grid.dat p95_abs_ind3_SON.nc gridded_p95_abs_ind3_SON.nc 
cdo enlarge,grid.dat p95_abs_ind4_SON.nc gridded_p95_abs_ind4_SON.nc 
cdo enlarge,grid.dat p95_abs_ind5_SON.nc gridded_p95_abs_ind5_SON.nc 
cdo enlarge,grid.dat p95_abs_ind6_SON.nc gridded_p95_abs_ind6_SON.nc

# 3. Normalize on percentile, for each seas, for each indicator 

# Now I normalize the indicators of the |prctl| 
# cdo div gives il the first input divided by the second input
# aka: cdo div first input/second input = third(output) 


cdo div ind1_DJF.nc gridded_p95_abs_ind1_DJF.nc norm_ind1_DJF.nc
cdo div ind2_DJF.nc gridded_p95_abs_ind2_DJF.nc norm_ind2_DJF.nc
cdo div ind3_DJF.nc gridded_p95_abs_ind3_DJF.nc norm_ind3_DJF.nc
cdo div ind4_DJF.nc gridded_p95_abs_ind4_DJF.nc norm_ind4_DJF.nc
cdo div ind5_DJF.nc gridded_p95_abs_ind5_DJF.nc norm_ind5_DJF.nc
cdo div ind6_DJF.nc gridded_p95_abs_ind6_DJF.nc norm_ind6_DJF.nc


cdo div ind1_MAM.nc gridded_p95_abs_ind1_MAM.nc norm_ind1_MAM.nc
cdo div ind2_MAM.nc gridded_p95_abs_ind2_MAM.nc norm_ind2_MAM.nc
cdo div ind3_MAM.nc gridded_p95_abs_ind3_MAM.nc norm_ind3_MAM.nc
cdo div ind4_MAM.nc gridded_p95_abs_ind4_MAM.nc norm_ind4_MAM.nc
cdo div ind5_MAM.nc gridded_p95_abs_ind5_MAM.nc norm_ind5_MAM.nc
cdo div ind6_MAM.nc gridded_p95_abs_ind6_MAM.nc norm_ind6_MAM.nc


cdo div ind1_JJA.nc gridded_p95_abs_ind1_JJA.nc norm_ind1_JJA.nc
cdo div ind2_JJA.nc gridded_p95_abs_ind2_JJA.nc norm_ind2_JJA.nc
cdo div ind3_JJA.nc gridded_p95_abs_ind3_JJA.nc norm_ind3_JJA.nc
cdo div ind4_JJA.nc gridded_p95_abs_ind4_JJA.nc norm_ind4_JJA.nc
cdo div ind5_JJA.nc gridded_p95_abs_ind5_JJA.nc norm_ind5_JJA.nc
cdo div ind6_JJA.nc gridded_p95_abs_ind6_JJA.nc norm_ind6_JJA.nc


cdo div ind1_SON.nc gridded_p95_abs_ind1_SON.nc norm_ind1_SON.nc
cdo div ind2_SON.nc gridded_p95_abs_ind2_SON.nc norm_ind2_SON.nc
cdo div ind3_SON.nc gridded_p95_abs_ind3_SON.nc norm_ind3_SON.nc
cdo div ind4_SON.nc gridded_p95_abs_ind4_SON.nc norm_ind4_SON.nc
cdo div ind5_SON.nc gridded_p95_abs_ind5_SON.nc norm_ind5_SON.nc
cdo div ind6_SON.nc gridded_p95_abs_ind6_SON.nc norm_ind6_SON.nc

# --- From now on is the same as before the improvement ---- 



# Ne faccio il quadrato 

# ind1: 

   cdo sqr norm_ind1_DJF.nc norm_ind1_DJF_allaseconda.nc
   cdo sqr norm_ind1_MAM.nc norm_ind1_MAM_allaseconda.nc
   cdo sqr norm_ind1_JJA.nc norm_ind1_JJA_allaseconda.nc
   cdo sqr norm_ind1_SON.nc norm_ind1_SON_allaseconda.nc

# ind2:
   cdo sqr norm_ind2_DJF.nc norm_ind2_DJF_allaseconda.nc
   cdo sqr norm_ind2_MAM.nc norm_ind2_MAM_allaseconda.nc
   cdo sqr norm_ind2_JJA.nc norm_ind2_JJA_allaseconda.nc
   cdo sqr norm_ind2_SON.nc norm_ind2_SON_allaseconda.nc
 
# ind3: 
   cdo sqr norm_ind3_DJF.nc norm_ind3_DJF_allaseconda.nc
   cdo sqr norm_ind3_MAM.nc norm_ind3_MAM_allaseconda.nc
   cdo sqr norm_ind3_JJA.nc norm_ind3_JJA_allaseconda.nc
   cdo sqr norm_ind3_SON.nc norm_ind3_SON_allaseconda.nc

# ind4:
   cdo sqr norm_ind4_DJF.nc norm_ind4_DJF_allaseconda.nc
   cdo sqr norm_ind4_MAM.nc norm_ind4_MAM_allaseconda.nc
   cdo sqr norm_ind4_JJA.nc norm_ind4_JJA_allaseconda.nc
   cdo sqr norm_ind4_SON.nc norm_ind4_SON_allaseconda.nc

# ind5:
   cdo sqr norm_ind5_DJF.nc norm_ind5_DJF_allaseconda.nc
   cdo sqr norm_ind5_MAM.nc norm_ind5_MAM_allaseconda.nc
   cdo sqr norm_ind5_JJA.nc norm_ind5_JJA_allaseconda.nc
   cdo sqr norm_ind5_SON.nc norm_ind5_SON_allaseconda.nc
 
# ind6:  
   cdo sqr norm_ind6_DJF.nc norm_ind6_DJF_allaseconda.nc
   cdo sqr norm_ind6_MAM.nc norm_ind6_MAM_allaseconda.nc
   cdo sqr norm_ind6_JJA.nc norm_ind6_JJA_allaseconda.nc
   cdo sqr norm_ind6_SON.nc norm_ind6_SON_allaseconda.nc

# For each indicator, sum over seasons so :  
# ----------------------------
# If All seasons:
# ----------------------------

# o2:

  # I merge in time, and then sum in time for each ind. 
cdo mergetime norm_ind1_DJF_allaseconda.nc norm_ind1_MAM_allaseconda.nc norm_ind1_JJA_allaseconda.nc norm_ind1_SON_allaseconda.nc norm_ind1_al2_merged.nc 
cdo mergetime norm_ind2_DJF_allaseconda.nc norm_ind2_MAM_allaseconda.nc norm_ind2_JJA_allaseconda.nc norm_ind2_SON_allaseconda.nc norm_ind2_al2_merged.nc 
cdo mergetime norm_ind3_DJF_allaseconda.nc norm_ind3_MAM_allaseconda.nc norm_ind3_JJA_allaseconda.nc norm_ind3_SON_allaseconda.nc norm_ind3_al2_merged.nc 
 
   # sum over time: 
cdo timsum norm_ind1_al2_merged.nc ind1normquad_timsummed.nc 
cdo timsum norm_ind2_al2_merged.nc ind2normquad_timsummed.nc 
cdo timsum norm_ind3_al2_merged.nc ind3normquad_timsummed.nc 


# ipvstar: 

   # I merge in time, and then sum in time for each ind. 
cdo mergetime norm_ind4_DJF_allaseconda.nc norm_ind4_MAM_allaseconda.nc norm_ind4_JJA_allaseconda.nc norm_ind4_SON_allaseconda.nc norm_ind4_al2_merged.nc 
cdo mergetime norm_ind5_DJF_allaseconda.nc norm_ind5_MAM_allaseconda.nc norm_ind5_JJA_allaseconda.nc norm_ind5_SON_allaseconda.nc norm_ind5_al2_merged.nc 
cdo mergetime norm_ind6_DJF_allaseconda.nc norm_ind6_MAM_allaseconda.nc norm_ind6_JJA_allaseconda.nc norm_ind6_SON_allaseconda.nc norm_ind6_al2_merged.nc 
 
   # sum over time: 
cdo timsum norm_ind4_al2_merged.nc ind4normquad_timsummed.nc 
cdo timsum norm_ind5_al2_merged.nc ind5normquad_timsummed.nc 
cdo timsum norm_ind6_al2_merged.nc ind6normquad_timsummed.nc 



# =============================
#  NOW SUM OVER INDICATORS: indicators 1+2+3+4+5+6+..+..+..etc  
# ============================

# ------------------------------
# If All seasons considered:
# ------------------------------

#sst
  cdo add ind1normquad_timsummed.nc ind2normquad_timsummed.nc 1piu2.nc    # 1+2 

# 1+2+3 (o2 only): 
  cdo add 1piu2.nc ind3normquad_timsummed.nc 1piu2piu3.nc                 # 1+2+3 = o2_all  

#mld
  cdo add ind4normquad_timsummed.nc ind5normquad_timsummed.nc 4piu5.nc    # 4+5 

# 4+5+6 (ipv only:)
  cdo add 4piu5.nc ind6normquad_timsummed.nc 4piu5piu6.nc                 # 4+5+6 = ipv_all
  
  #cdo add ind5normquad_timsummed.nc ind6normquad_timsummed.nc 5piu6.nc    # 5+6 
  #cdo add ind4normquad_timsummed.nc ind6normquad_timsummed.nc 4piu6.nc    # 4+6  


# =============================================
# FINAL ARGUMENTS TO PUT IN SQUARE ROOT  
# =============================================

# -------------------------------
# If All seasons: 
# -------------------------------

# 1+2+3 + 4+5+6: SST all + MLD all: 
 
  cdo add 1piu2piu3.nc 4piu5piu6.nc All_argumentRadice.nc 	    # 1+2+3+4+5+6: o2_all and ipv_all
 

# ================================================================
#  Finally, I compute SED as the square root of the argument: 
# ================================================================


# ---------------------------------------------------
# (a) All seasons, All indicators: 1+2+3+4+5+6
# ---------------------------------------------------
 
 cdo sqrt All_argumentRadice.nc SED_HotSpotIndex_1-to-6.nc # ind1 to ind9


 # All seasons, only o2: 1+2+3
 cdo sqrt 1piu2piu3.nc SED_HotSpotIndex_123.nc

 # All seasons, only ipvstar: 4+5+6

 cdo sqrt 4piu5piu6.nc SED_HotSpotIndex_456.nc
# Tidy up the folders:  

mv All_argumentRadice.nc tmp_files/
mv *normquad* tmp_files/
mv *norm_ind* tmp_files/
#mv *p95_abs* tmp_files/
#
mkdir SED
mv *SED_* SED
mv *ind* indicators
#
mv indicators/*.sh . 
#
mkdir trash
mv *.nc ./trash
rm ./trash/*
rm ./tmp_files/* 

mv SED/* . 
rmdir SED 
rmdir trash 






# -----------------------------------------------------------------------------------------
# *************** END OF CODE ****************** 




 
