#!/bin/bash

./1_GFDL-ESM4_compute_indicators.sh
./3_compute_SED_GFDL-ESM4.sh



