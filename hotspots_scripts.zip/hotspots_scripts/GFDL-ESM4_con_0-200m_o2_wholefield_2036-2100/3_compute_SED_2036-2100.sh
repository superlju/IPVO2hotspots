#!/bin/bash

# ----- PART ADDED TO NORMALIZED ON HISTORICAL p95 ---------------------

# copy histroical p95 indicators from historical to here.
cp ../GFDL-ESM4_con_0-200m_o2_wholefield_1950-2014/indicators/p95_abs_* .

# then keep going as usual, but now you will normalize on the same p95 you have used for the historical.

# ----------------------------------------------------------------------


# 1. get grid.dat file that contains grid structure: 

cdo griddes ind1_DJF.nc > grid.dat  # it's the same for all the ind so I just do this once. 


# 2. Transform percentiles files from point values to grid values, otherwise we can't divide: 
# grid is teh grid of the data 

cdo enlarge,grid.dat p95_abs_ind1_DJF.nc gridded_p95_abs_ind1_DJF.nc    # percentile grigliato, non più numero singolo. 
cdo enlarge,grid.dat p95_abs_ind2_DJF.nc gridded_p95_abs_ind2_DJF.nc 
cdo enlarge,grid.dat p95_abs_ind3_DJF.nc gridded_p95_abs_ind3_DJF.nc 
cdo enlarge,grid.dat p95_abs_ind4_DJF.nc gridded_p95_abs_ind4_DJF.nc 
cdo enlarge,grid.dat p95_abs_ind5_DJF.nc gridded_p95_abs_ind5_DJF.nc 
cdo enlarge,grid.dat p95_abs_ind6_DJF.nc gridded_p95_abs_ind6_DJF.nc 

cdo enlarge,grid.dat p95_abs_ind1_MAM.nc gridded_p95_abs_ind1_MAM.nc    # percentile grigliato, non più numero singolo. 
cdo enlarge,grid.dat p95_abs_ind2_MAM.nc gridded_p95_abs_ind2_MAM.nc 
cdo enlarge,grid.dat p95_abs_ind3_MAM.nc gridded_p95_abs_ind3_MAM.nc 
cdo enlarge,grid.dat p95_abs_ind4_MAM.nc gridded_p95_abs_ind4_MAM.nc 
cdo enlarge,grid.dat p95_abs_ind5_MAM.nc gridded_p95_abs_ind5_MAM.nc 
cdo enlarge,grid.dat p95_abs_ind6_MAM.nc gridded_p95_abs_ind6_MAM.nc

cdo enlarge,grid.dat p95_abs_ind1_JJA.nc gridded_p95_abs_ind1_JJA.nc    # percentile grigliato, non più numero singolo. 
cdo enlarge,grid.dat p95_abs_ind2_JJA.nc gridded_p95_abs_ind2_JJA.nc 
cdo enlarge,grid.dat p95_abs_ind3_JJA.nc gridded_p95_abs_ind3_JJA.nc 
cdo enlarge,grid.dat p95_abs_ind4_JJA.nc gridded_p95_abs_ind4_JJA.nc 
cdo enlarge,grid.dat p95_abs_ind5_JJA.nc gridded_p95_abs_ind5_JJA.nc 
cdo enlarge,grid.dat p95_abs_ind6_JJA.nc gridded_p95_abs_ind6_JJA.nc

cdo enlarge,grid.dat p95_abs_ind1_SON.nc gridded_p95_abs_ind1_SON.nc    # percentile grigliato, non più numero singolo. 
cdo enlarge,grid.dat p95_abs_ind2_SON.nc gridded_p95_abs_ind2_SON.nc 
cdo enlarge,grid.dat p95_abs_ind3_SON.nc gridded_p95_abs_ind3_SON.nc 
cdo enlarge,grid.dat p95_abs_ind4_SON.nc gridded_p95_abs_ind4_SON.nc 
cdo enlarge,grid.dat p95_abs_ind5_SON.nc gridded_p95_abs_ind5_SON.nc 
cdo enlarge,grid.dat p95_abs_ind6_SON.nc gridded_p95_abs_ind6_SON.nc

# 3. Normalizzo sul percentile, for each seas, for each indicator 

# Now I normalize the indicators of the |prctl| 
# cdo div fornisce il primo input diviso il secondo input
# cioe: cdo div primo/secondo = terzo 


cdo div ind1_DJF.nc gridded_p95_abs_ind1_DJF.nc norm_ind1_DJF.nc
cdo div ind2_DJF.nc gridded_p95_abs_ind2_DJF.nc norm_ind2_DJF.nc
cdo div ind3_DJF.nc gridded_p95_abs_ind3_DJF.nc norm_ind3_DJF.nc
cdo div ind4_DJF.nc gridded_p95_abs_ind4_DJF.nc norm_ind4_DJF.nc
cdo div ind5_DJF.nc gridded_p95_abs_ind5_DJF.nc norm_ind5_DJF.nc
cdo div ind6_DJF.nc gridded_p95_abs_ind6_DJF.nc norm_ind6_DJF.nc


cdo div ind1_MAM.nc gridded_p95_abs_ind1_MAM.nc norm_ind1_MAM.nc
cdo div ind2_MAM.nc gridded_p95_abs_ind2_MAM.nc norm_ind2_MAM.nc
cdo div ind3_MAM.nc gridded_p95_abs_ind3_MAM.nc norm_ind3_MAM.nc
cdo div ind4_MAM.nc gridded_p95_abs_ind4_MAM.nc norm_ind4_MAM.nc
cdo div ind5_MAM.nc gridded_p95_abs_ind5_MAM.nc norm_ind5_MAM.nc
cdo div ind6_MAM.nc gridded_p95_abs_ind6_MAM.nc norm_ind6_MAM.nc


cdo div ind1_JJA.nc gridded_p95_abs_ind1_JJA.nc norm_ind1_JJA.nc
cdo div ind2_JJA.nc gridded_p95_abs_ind2_JJA.nc norm_ind2_JJA.nc
cdo div ind3_JJA.nc gridded_p95_abs_ind3_JJA.nc norm_ind3_JJA.nc
cdo div ind4_JJA.nc gridded_p95_abs_ind4_JJA.nc norm_ind4_JJA.nc
cdo div ind5_JJA.nc gridded_p95_abs_ind5_JJA.nc norm_ind5_JJA.nc
cdo div ind6_JJA.nc gridded_p95_abs_ind6_JJA.nc norm_ind6_JJA.nc


cdo div ind1_SON.nc gridded_p95_abs_ind1_SON.nc norm_ind1_SON.nc
cdo div ind2_SON.nc gridded_p95_abs_ind2_SON.nc norm_ind2_SON.nc
cdo div ind3_SON.nc gridded_p95_abs_ind3_SON.nc norm_ind3_SON.nc
cdo div ind4_SON.nc gridded_p95_abs_ind4_SON.nc norm_ind4_SON.nc
cdo div ind5_SON.nc gridded_p95_abs_ind5_SON.nc norm_ind5_SON.nc
cdo div ind6_SON.nc gridded_p95_abs_ind6_SON.nc norm_ind6_SON.nc

# --- From now on is the same as before the improvement ---- 



# Ne faccio il quadrato

# ind1: 

   cdo sqr norm_ind1_DJF.nc norm_ind1_DJF_allaseconda.nc
   cdo sqr norm_ind1_MAM.nc norm_ind1_MAM_allaseconda.nc
   cdo sqr norm_ind1_JJA.nc norm_ind1_JJA_allaseconda.nc
   cdo sqr norm_ind1_SON.nc norm_ind1_SON_allaseconda.nc

# ind2:
   cdo sqr norm_ind2_DJF.nc norm_ind2_DJF_allaseconda.nc
   cdo sqr norm_ind2_MAM.nc norm_ind2_MAM_allaseconda.nc
   cdo sqr norm_ind2_JJA.nc norm_ind2_JJA_allaseconda.nc
   cdo sqr norm_ind2_SON.nc norm_ind2_SON_allaseconda.nc
 
# ind3: 
   cdo sqr norm_ind3_DJF.nc norm_ind3_DJF_allaseconda.nc
   cdo sqr norm_ind3_MAM.nc norm_ind3_MAM_allaseconda.nc
   cdo sqr norm_ind3_JJA.nc norm_ind3_JJA_allaseconda.nc
   cdo sqr norm_ind3_SON.nc norm_ind3_SON_allaseconda.nc

# ind4:
   cdo sqr norm_ind4_DJF.nc norm_ind4_DJF_allaseconda.nc
   cdo sqr norm_ind4_MAM.nc norm_ind4_MAM_allaseconda.nc
   cdo sqr norm_ind4_JJA.nc norm_ind4_JJA_allaseconda.nc
   cdo sqr norm_ind4_SON.nc norm_ind4_SON_allaseconda.nc

# ind5:
   cdo sqr norm_ind5_DJF.nc norm_ind5_DJF_allaseconda.nc
   cdo sqr norm_ind5_MAM.nc norm_ind5_MAM_allaseconda.nc
   cdo sqr norm_ind5_JJA.nc norm_ind5_JJA_allaseconda.nc
   cdo sqr norm_ind5_SON.nc norm_ind5_SON_allaseconda.nc
 
# ind6:  
   cdo sqr norm_ind6_DJF.nc norm_ind6_DJF_allaseconda.nc
   cdo sqr norm_ind6_MAM.nc norm_ind6_MAM_allaseconda.nc
   cdo sqr norm_ind6_JJA.nc norm_ind6_JJA_allaseconda.nc
   cdo sqr norm_ind6_SON.nc norm_ind6_SON_allaseconda.nc

# For each indicator, sum over seasons so :  
# ----------------------------
# If All seasons:
# ----------------------------

# o2:

  # I merge in time, and then sum in time for each ind. 
cdo mergetime norm_ind1_DJF_allaseconda.nc norm_ind1_MAM_allaseconda.nc norm_ind1_JJA_allaseconda.nc norm_ind1_SON_allaseconda.nc norm_ind1_al2_merged.nc 
cdo mergetime norm_ind2_DJF_allaseconda.nc norm_ind2_MAM_allaseconda.nc norm_ind2_JJA_allaseconda.nc norm_ind2_SON_allaseconda.nc norm_ind2_al2_merged.nc 
cdo mergetime norm_ind3_DJF_allaseconda.nc norm_ind3_MAM_allaseconda.nc norm_ind3_JJA_allaseconda.nc norm_ind3_SON_allaseconda.nc norm_ind3_al2_merged.nc 
 
   # sum over time: 
cdo timsum norm_ind1_al2_merged.nc ind1normquad_timsummed.nc 
cdo timsum norm_ind2_al2_merged.nc ind2normquad_timsummed.nc 
cdo timsum norm_ind3_al2_merged.nc ind3normquad_timsummed.nc 


# ipvstar: 

   # I merge in time, and then sum in time for each ind. 
cdo mergetime norm_ind4_DJF_allaseconda.nc norm_ind4_MAM_allaseconda.nc norm_ind4_JJA_allaseconda.nc norm_ind4_SON_allaseconda.nc norm_ind4_al2_merged.nc 
cdo mergetime norm_ind5_DJF_allaseconda.nc norm_ind5_MAM_allaseconda.nc norm_ind5_JJA_allaseconda.nc norm_ind5_SON_allaseconda.nc norm_ind5_al2_merged.nc 
cdo mergetime norm_ind6_DJF_allaseconda.nc norm_ind6_MAM_allaseconda.nc norm_ind6_JJA_allaseconda.nc norm_ind6_SON_allaseconda.nc norm_ind6_al2_merged.nc 
 
   # sum over time: 
cdo timsum norm_ind4_al2_merged.nc ind4normquad_timsummed.nc 
cdo timsum norm_ind5_al2_merged.nc ind5normquad_timsummed.nc 
cdo timsum norm_ind6_al2_merged.nc ind6normquad_timsummed.nc 



# =============================
#  NOW SUM OVER INDICATORS: indicators 1+2+3+4+5+6+..+..+..etc (dopo devo fare la tradice per avere il SED) 
# ============================

# ------------------------------
# If All seasons considered:
# ------------------------------

#sst
  cdo add ind1normquad_timsummed.nc ind2normquad_timsummed.nc 1piu2.nc    # 1+2 

# 1+2+3 (o2 only): 
  cdo add 1piu2.nc ind3normquad_timsummed.nc 1piu2piu3.nc                 # 1+2+3 = o2_all  

#mld
  cdo add ind4normquad_timsummed.nc ind5normquad_timsummed.nc 4piu5.nc    # 4+5 

# 4+5+6 (ipv only:)
  cdo add 4piu5.nc ind6normquad_timsummed.nc 4piu5piu6.nc                 # 4+5+6 = ipv_all
  
  #cdo add ind5normquad_timsummed.nc ind6normquad_timsummed.nc 5piu6.nc    # 5+6 
  #cdo add ind4normquad_timsummed.nc ind6normquad_timsummed.nc 4piu6.nc    # 4+6  


# =============================================
# ARGOMENTI FINALI DA METTERE SOTTO RADICE  
# =============================================

# -------------------------------
# If All seasons: 
# -------------------------------

# 1+2+3 + 4+5+6: SST all + MLD all: 
 
  cdo add 1piu2piu3.nc 4piu5piu6.nc All_argumentRadice.nc 	    # 1+2+3+4+5+6: o2_all and ipv_all
 

# ================================================================
#  Finally, I compute SED as the square root of the argument: 
# ================================================================


# ---------------------------------------------------
# (a) All seasons, All indicators: 1+2+3+4+5+6
# ---------------------------------------------------
 
 cdo sqrt All_argumentRadice.nc SED_HotSpotIndex_1-to-6.nc # ind1 to ind9


 # All seasons, only o2: 1+2+3
 cdo sqrt 1piu2piu3.nc SED_HotSpotIndex_123.nc

 # All seasons, only ipvstar: 4+5+6

 cdo sqrt 4piu5piu6.nc SED_HotSpotIndex_456.nc

 # Calcolo anche SED senza contributo degli indicatori degli estremi, 
 # perchè in questo caso particolare ho i p95 historical che sono zero e quindi mi vengono NaNs quando divido per zero.
 
 cdo sqrt 1piu2.nc SED_HotSpotIndex_12.nc
 cdo sqrt 4piu5.nc SED_HotSpotIndex_45.nc

# Tidy up the folders:  

mv All_argumentRadice.nc tmp_files/
mv *normquad* tmp_files/
mv *norm_ind* tmp_files/
mv *p95_abs* tmp_files/
#
mkdir SED
mv *SED_* SED
mv *ind* indicators
#
mv indicators/*.sh . 
#
mkdir trash
mv *.nc ./trash
rm ./trash/*
rm ./tmp_files/* 

mv SED/* . 
rmdir SED 
rmdir trash 






# -----------------------------------------------------------------------------------------
# ************* NOT DONE YET UNDER THIS LINE ******************** 


# Sensitivity: 

# All tranne MLT cioè 1,2,3, 7,8,9, 10,11,12, 13,14,15
# cdo sqrt All-without-mld_argumentRadice.nc SED_HotSpotIndex_all-without-mld.nc  





# *** MLD combinations: ***

# Only mdl indicators: 4,5,6 

#cdo sqrt 4piu5piu6.nc SED_HotSpotIndex_4-5-6.nc # ind4, ind5, ind6
 


# *** SST combinations: ***  
 # Only sst indicators: 1,2,3 
 #cdo sqrt 1piu2piu3.nc SED_HotSpotIndex_1-2-3.nc # ind1, ind2, ind3 



# *** SSAL combinations: ***  

 # Only ssal indicators: 7,8,9
 #cdo sqrt 7piu8piu9.nc SED_HotSpotIndex_7-8-9.nc  


# ***************************  




