#!/bin/bash

./1_compute_indicators_2036-2100.sh
./3_compute_SED_2036-2100.sh



