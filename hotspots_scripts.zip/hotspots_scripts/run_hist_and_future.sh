
#!/bin/bash

# =================================
#  Always run historical first: 
# =================================

cd GFDL-ESM4_con_0-200m_o2_wholefield_1950-2014
rm *.nc
rm indicators/*.nc
./run_all.sh
cd ..

# =================================
#  Run future after:  
# =================================

cd GFDL-ESM4_con_0-200m_o2_wholefield_2036-2100
rm *.nc
rm indicators/*.nc
./run_all.sh
cd ..


